Reemplaza el archivo share\icons\icons.svg (en la carpeta del programa) por este.

- Por ejemplo, en Windows x64:

C:\Program Files\Inkscape\share\icons\icons.svg

- En Windows x86:

C:\Program Files (x86)\Inkscape\share\icons\icons.svg